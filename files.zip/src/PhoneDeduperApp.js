import React, { useState } from "react";
import Papa from "papaparse";

// Phone Deduper React component (single-file app)
// Usage: drop this file into a React app (e.g. create-react-app), install papaparse
//    npm install papaparse
// Then import and render <PhoneDeduperApp />

export default function PhoneDeduperApp() {
  const [files, setFiles] = useState([]);
  const [status, setStatus] = useState("");
  const [totalRows, setTotalRows] = useState(0);
  const [uniqueCount, setUniqueCount] = useState(0);
  const [invalidCount, setInvalidCount] = useState(0);
  const [duplicatesCount, setDuplicatesCount] = useState(0);
  const [resultNumbers, setResultNumbers] = useState([]);
  const [preview, setPreview] = useState([]);

  // Normalize a phone number string to 10-digit US number if possible.
  // Rules:
  // - Remove all non-digits
  // - If 11 digits and starts with 1 -> drop leading 1
  // - If exactly 10 digits -> accept
  // - Else -> invalid
  function normalizeUSPhone(raw) {
    if (!raw && raw !== 0) return null;
    const s = String(raw).replace(/[^0-9]/g, "");
    if (s.length === 11 && s.startsWith("1")) return s.slice(1);
    if (s.length === 10) return s;
    return null;
  }

  function onFilesChange(e) {
    setFiles(Array.from(e.target.files));
    setStatus("");
    setTotalRows(0);
    setUniqueCount(0);
    setInvalidCount(0);
    setDuplicatesCount(0);
    setResultNumbers([]);
    setPreview([]);
  }

  async function handleProcess() {
    if (!files || files.length === 0) {
      setStatus("Please select 1 or more CSV files.");
      return;
    }

    setStatus("Parsing files...");

    // Use a set to track unique normalized numbers
    const seen = new Set();
    const bad = new Set();
    let total = 0;
    let duplicates = 0;

    // We'll keep insertion order of unique numbers in array
    const uniqueArray = [];

    // Helper to parse a single file and extract column A values
    const parseFile = (file) =>
      new Promise((resolve) => {
        Papa.parse(file, {
          complete: (results) => resolve(results),
          error: () => resolve({ data: [], errors: ["parse_error"] }),
          skipEmptyLines: true,
        });
      });

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setStatus(`Parsing ${file.name} (${i + 1}/${files.length})`);
      const results = await parseFile(file);
      const rows = results && results.data ? results.data : [];

      for (const row of rows) {
        total += 1;
        let rawColA = null;
        if (Array.isArray(row)) rawColA = row[0];
        else if (typeof row === "object" && row !== null) {
          const keys = Object.keys(row);
          rawColA = keys.length ? row[keys[0]] : null;
        } else {
          rawColA = row;
        }

        const norm = normalizeUSPhone(rawColA);
        if (!norm) {
          bad.add(String(rawColA || ""));
          continue;
        }
        if (seen.has(norm)) {
          duplicates += 1;
        } else {
          seen.add(norm);
          uniqueArray.push(norm);
        }
      }
    }

    setTotalRows(total);
    setInvalidCount(bad.size);
    setDuplicatesCount(duplicates);
    setUniqueCount(seen.size);
    setResultNumbers(uniqueArray);
    setPreview(uniqueArray.slice(0, 20));
    setStatus("Done — download your deduped CSV below.");
  }

  function downloadCsv() {
    if (!resultNumbers || resultNumbers.length === 0) return;
    const rows = ["phone", ...resultNumbers.map((p) => formatForOutput(p))];
    const blob = new Blob([rows.join("\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
    a.download = `deduped-us-phones-${timestamp}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  function formatForOutput(number10) {
    if (!number10) return "";
    return `+1${number10}`;
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-2xl shadow-md p-6">
        <h1 className="text-2xl font-semibold mb-4">Phone Deduper — US numbers (Column A)</h1>
        <p className="mb-4 text-sm text-slate-600">
          Upload one or more CSV files. The app will read <strong>Column A</strong> from each file,
          normalize to 10-digit US numbers (strip country code 1 if present), remove duplicates across all
          files and produce a single CSV containing good numbers in <code>+1NNNNNNNNNN</code> format.
        </p>

        <label className="block mb-3">
          <span className="sr-only">CSV files</span>
          <input
            type="file"
            accept=".csv,text/csv"
            multiple
            onChange={onFilesChange}
            className="block w-full text-sm text-slate-700 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-slate-100 hover:file:bg-slate-200"
          />
        </label>

        <div className="flex gap-2">
          <button
            onClick={handleProcess}
            className="px-4 py-2 rounded-lg shadow-sm bg-indigo-600 text-white hover:bg-indigo-700"
          >
            Process files
          </button>

          <button
            onClick={downloadCsv}
            className="px-4 py-2 rounded-lg shadow-sm bg-green-600 text-white hover:bg-green-700"
            disabled={!resultNumbers || resultNumbers.length === 0}
          >
            Download CSV
          </button>

          <button
            onClick={() => {
              setFiles([]);
              setStatus("");
              setTotalRows(0);
              setUniqueCount(0);
              setInvalidCount(0);
              setDuplicatesCount(0);
              setResultNumbers([]);
              setPreview([]);
              const input = document.querySelector('input[type=file]');
              if (input) input.value = null;
            }}
            className="px-4 py-2 rounded-lg shadow-sm bg-gray-100 text-slate-700 hover:bg-gray-200"
          >
            Reset
          </button>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-4">
          <div className="p-4 bg-slate-50 rounded-lg">
            <div className="text-sm text-slate-500">Status</div>
            <div className="font-medium mt-1">{status || "Waiting"}</div>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg">
            <div className="text-sm text-slate-500">Files selected</div>
            <div className="font-medium mt-1">{files.length}</div>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg">
            <div className="text-sm text-slate-500">Total rows read</div>
            <div className="font-medium mt-1">{totalRows}</div>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg">
            <div className="text-sm text-slate-500">Unique good numbers</div>
            <div className="font-medium mt-1">{uniqueCount}</div>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg">
            <div className="text-sm text-slate-500">Invalid / unrecognized</div>
            <div className="font-medium mt-1">{invalidCount}</div>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg">
            <div className="text-sm text-slate-500">Duplicates removed</div>
            <div className="font-medium mt-1">{duplicatesCount}</div>
          </div>
        </div>

        <div className="mt-6">
          <h2 className="text-lg font-semibold">Preview (first 20 unique)</h2>
          <div className="mt-2">
            {preview.length === 0 ? (
              <div className="text-sm text-slate-500">No preview available</div>
            ) : (
              <ol className="list-decimal list-inside">
                {preview.map((p) => (
                  <li key={p} className="text-sm">
                    {formatForOutput(p)}
                  </li>
                ))}
              </ol>
            )}
          </div>
        </div>

        <div className="mt-6 text-sm text-slate-500">
          <strong>Notes & tips:</strong>
          <ul className="list-disc list-inside mt-2">
            <li>Only Column A is used from each CSV (first column). If your phone numbers are in a different column, export or reorder them first.</li>
            <li>Numbers are normalized to 10 digits — leading a US country code of +1 or 1 is removed. Numbers that don't become 10 digits are counted as invalid and excluded.</li>
            <li>The output CSV uses E.164-like format <code>+1XXXXXXXXXX</code> in a single column named <code>phone</code>.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}