import React from "react";
import PhoneDeduperApp from "./PhoneDeduperApp";

function App() {
  return <PhoneDeduperApp />;
}

export default App;