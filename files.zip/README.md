# Phone Deduper

A simple React app to deduplicate US phone numbers from CSV files.

## Features

- Upload one or more CSV files containing phone numbers in the first column.
- Normalizes US phone numbers to 10 digits, removing duplicates and invalid entries.
- Download the deduped list as a new CSV in E.164 format (`+1XXXXXXXXXX`).

## Getting Started

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Start the development server**
   ```bash
   npm start
   ```

3. **Build for production**
   ```bash
   npm run build
   ```

## Deploying on GitHub Pages

1. **Install gh-pages**
   ```bash
   npm install --save gh-pages
   ```

2. **Deploy**
   ```bash
   npm run deploy
   ```

Your app will be live at: `https://jasongreyislive-svg.github.io/phone-deduper`

## Tailwind CSS

This app uses Tailwind CSS for styling. See `tailwind.config.js` and `src/index.css` for details.

## License

MIT